DO NOT USE THOSE SCRIPTS !!!!! They are for testing purposes only!

Use only in Virtual Machine or create a system backup beforehand!

USE AT OWN RISK AS IS without support or warranty of any kind !

It is a collection of tweaks for my use published for copy/paste.
